package com.millionnaire.abidjan;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import java.util.Locale;
import java.util.UUID;

/** Permet au jeu (HTML) de faire parler le téléphone, avec une voix plus grave ou plus aiguë selon le personnage. */
public class TtsBridge {

    private final TextToSpeech tts;
    private volatile boolean ready = false;

    public TtsBridge(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts_setFrench();
                ready = true;
            }
        });
    }

    private void tts_setFrench() {
        try {
            tts.setLanguage(Locale.FRANCE);
        } catch (Exception ignored) {
        }
    }

    @JavascriptInterface
    public void speak(String text, double pitch, double rate, boolean flush) {
        if (!ready || text == null) return;
        tts.setPitch((float) pitch);
        tts.setSpeechRate((float) rate);
        tts.speak(text,
                flush ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                null,
                UUID.randomUUID().toString());
    }

    @JavascriptInterface
    public void stop() {
        tts.stop();
    }

    public void shutdown() {
        tts.stop();
        tts.shutdown();
    }
}
